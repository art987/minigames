import { useWorkbench } from '../store/workbench'

/** 色卡编辑面板：显示 / 改色 / 重命名 / 选中当前画笔 */
export default function PalettePanel() {
  const palette = useWorkbench((s) => s.palette)
  const selected = useWorkbench((s) => s.selectedColorIndex)
  const setSelected = useWorkbench((s) => s.setSelectedColorIndex)
  const updateColor = useWorkbench((s) => s.updateColor)
  const renameColor = useWorkbench((s) => s.renameColor)

  return (
    <div className="space-y-2">
      <div className="text-xs text-zinc-400">色卡（{palette.colors.length} 色）</div>
      <div className="grid grid-cols-2 gap-2">
        {palette.colors.map((c) => (
          <div
            key={c.index}
            onClick={() => setSelected(c.index)}
            className={`flex cursor-pointer items-center gap-2 rounded-md border p-1.5 transition ${
              selected === c.index
                ? 'border-indigo-400 bg-indigo-500/15 ring-1 ring-indigo-400'
                : 'border-zinc-700 bg-zinc-800 hover:border-zinc-500'
            }`}
          >
            <label className="relative h-8 w-8 shrink-0 cursor-pointer rounded" style={{ background: c.hex }}>
              <input
                type="color"
                value={c.hex}
                onChange={(e) => updateColor(c.index, e.target.value.toUpperCase())}
                className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
              />
            </label>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[10px] text-zinc-400">#{c.hex.slice(1)}</div>
              <input
                value={c.name}
                onChange={(e) => renameColor(c.index, e.target.value)}
                onClick={(e) => e.stopPropagation()}
                className="w-full truncate bg-transparent text-xs text-zinc-200 outline-none focus:text-indigo-300"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
