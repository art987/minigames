import { useState } from 'react'
import { useWorkbench } from './store/workbench'
import KnitCanvas from './components/KnitCanvas'
import ParamsPanel from './components/ParamsPanel'
import PalettePanel from './components/PalettePanel'
import ImageUploader from './components/ImageUploader'
import WorkList from './components/WorkList'

export default function App() {
  const projectName = useWorkbench((s) => s.projectName)
  const setProjectName = useWorkbench((s) => s.setProjectName)
  const matrix = useWorkbench((s) => s.matrix)
  const save = useWorkbench((s) => s.save)
  const newProject = useWorkbench((s) => s.newProject)
  const dirty = useWorkbench((s) => s.dirty)
  const tool = useWorkbench((s) => s.tool)
  const setTool = useWorkbench((s) => s.setTool)
  const selectedColorIndex = useWorkbench((s) => s.selectedColorIndex)
  const palette = useWorkbench((s) => s.palette)
  const showGrid = useWorkbench((s) => s.showGrid)
  const setShowGrid = useWorkbench((s) => s.setShowGrid)
  const toast = useWorkbench((s) => s.toast)
  const [showWorks, setShowWorks] = useState(false)

  const selectedColor = palette.colors.find((c) => c.index === selectedColorIndex)

  return (
    <div className="flex h-screen flex-col bg-zinc-900 text-zinc-100">
      {/* 顶栏 */}
      <header className="flex h-12 shrink-0 items-center gap-3 border-b border-zinc-800 bg-zinc-950 px-4">
        <span className="text-sm font-bold tracking-widest text-indigo-400">ARTKNIT STUDIO</span>
        <input
          value={projectName}
          onChange={(e) => setProjectName(e.target.value)}
          className="w-48 rounded border border-transparent bg-transparent px-2 py-1 text-sm hover:border-zinc-700 focus:border-indigo-500 focus:outline-none"
        />
        <div className="flex-1" />
        <button onClick={() => setShowWorks((v) => !v)} className="rounded px-3 py-1.5 text-xs text-zinc-300 hover:bg-zinc-800">
          本地作品
        </button>
        <button onClick={newProject} className="rounded px-3 py-1.5 text-xs text-zinc-300 hover:bg-zinc-800">
          新建
        </button>
        <button
          onClick={save}
          disabled={matrix.length === 0}
          className="rounded-md bg-indigo-600 px-4 py-1.5 text-xs font-medium text-white hover:bg-indigo-500 disabled:opacity-40"
        >
          保存{dirty ? ' *' : ''}
        </button>
      </header>

      <div className="flex min-h-0 flex-1">
        {/* 左侧：参数 + 色卡 */}
        <aside className="w-72 shrink-0 space-y-5 overflow-y-auto border-r border-zinc-800 bg-zinc-950 p-4">
          <section>
            <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-500">转换参数</h2>
            <ParamsPanel />
          </section>
          {palette.colors.length > 0 && (
            <section>
              <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-500">色卡</h2>
              <PalettePanel />
            </section>
          )}
        </aside>

        {/* 中央：画布 */}
        <main className="relative min-w-0 flex-1 bg-[#1e1e24]">
          {matrix.length === 0 ? (
            <ImageUploader />
          ) : (
            <KnitCanvas />
          )}
          {/* 工具条 */}
          {matrix.length > 0 && (
            <div className="absolute left-3 top-3 flex items-center gap-2 rounded-lg border border-zinc-700 bg-zinc-900/90 p-1.5 shadow-lg">
              <label className="relative h-7 w-7 cursor-pointer rounded border border-zinc-600" style={{ background: selectedColor?.hex ?? '#fff' }} title="当前画笔颜色" />
              <button
                onClick={() => setTool('paint')}
                className={`rounded px-2.5 py-1 text-xs ${tool === 'paint' ? 'bg-indigo-600 text-white' : 'text-zinc-300 hover:bg-zinc-800'}`}
              >
                绘制
              </button>
              <button
                onClick={() => setTool('pick')}
                className={`rounded px-2.5 py-1 text-xs ${tool === 'pick' ? 'bg-indigo-600 text-white' : 'text-zinc-300 hover:bg-zinc-800'}`}
              >
                取色
              </button>
              <label className="flex cursor-pointer items-center gap-1.5 border-l border-zinc-700 pl-2 text-xs text-zinc-300">
                <input type="checkbox" checked={showGrid} onChange={(e) => setShowGrid(e.target.checked)} className="h-3.5 w-3.5 accent-indigo-500" />
                网格
              </label>
            </div>
          )}
          {/* 本地作品面板 */}
          {showWorks && (
            <div className="absolute right-3 top-3 w-80 rounded-lg border border-zinc-700 bg-zinc-900/95 p-3 shadow-2xl">
              <WorkList onClose={() => setShowWorks(false)} />
            </div>
          )}
        </main>
      </div>

      {/* Toast */}
      {toast && (
        <div className="pointer-events-none fixed bottom-6 left-1/2 -translate-x-1/2 rounded-lg bg-zinc-800 px-4 py-2 text-sm text-zinc-100 shadow-xl ring-1 ring-zinc-600">
          {toast}
        </div>
      )}
    </div>
  )
}
