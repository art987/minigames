/**
 * 工作台全局状态（Zustand）
 */
import { create } from 'zustand'
import type { AknColor, AknConvertParams, AknProjectMeta, AknPalette } from '../types/akn'
import { newId, saveProject, loadProject, deleteProject, listProjects } from '../db/idb'
import { convertImage, debounce, readImageFile, type SourceImage } from '../lib/convertClient'

const DEFAULT_PARAMS: AknConvertParams = {
  stitches: 100,
  rows: 100,
  colorCount: 8,
  dithering: true,
  algorithm: 'kmeans',
  sharpen: 20,
}

interface WorkbenchState {
  /* 当前工程 */
  projectId: string | null
  projectName: string
  params: AknConvertParams
  palette: AknPalette
  matrix: number[][]
  source: SourceImage | null
  thumbnail: string | null
  /* 状态 */
  busy: boolean
  dirty: boolean
  works: AknProjectMeta[]
  selectedColorIndex: number
  tool: 'paint' | 'pick'
  showGrid: boolean
  toast: string | null
  setShowGrid: (v: boolean) => void

  setParams: (patch: Partial<AknConvertParams>) => void
  setImage: (file: File) => Promise<void>
  setMatrix: (matrix: number[][], palette: AknColor[]) => void
  paintCell: (row: number, col: number) => void
  setSelectedColorIndex: (i: number) => void
  setTool: (t: 'paint' | 'pick') => void
  updateColor: (index: number, hex: string) => void
  renameColor: (index: number, name: string) => void
  setColorCount: (n: number) => void
  setProjectName: (name: string) => void
  save: () => Promise<void>
  open: (id: string) => Promise<void>
  remove: (id: string) => Promise<void>
  refreshWorks: () => Promise<void>
  newProject: () => void
  showToast: (msg: string) => void
}

function paletteFrom(colors: AknColor[]): AknPalette {
  return { id: newId(), name: '自动色卡', colors }
}

function makeThumbnail(matrix: number[][], colors: AknColor[]): string {
  const h = matrix.length
  const w = h > 0 ? matrix[0].length : 0
  if (!w || !h) return ''
  const canvas = document.createElement('canvas')
  canvas.width = Math.min(w, 120)
  canvas.height = Math.round((canvas.width * h) / w)
  const ctx = canvas.getContext('2d')!
  const cell = 1
  for (let y = 0; y < canvas.height; y++) {
    const sy = Math.floor((y / canvas.height) * h)
    for (let x = 0; x < canvas.width; x++) {
      const sx = Math.floor((x / canvas.width) * w)
      const idx = matrix[sy]?.[sx] ?? -1
      const c = colors.find((cc) => cc.index === idx)
      ctx.fillStyle = c ? c.hex : '#ffffff'
      ctx.fillRect(x * cell, y * cell, cell, cell)
    }
  }
  return canvas.toDataURL('image/png')
}

/** 完整转换防抖 350ms */
let runFullDebounced: ((source: SourceImage, params: AknConvertParams) => void) | null = null

export const useWorkbench = create<WorkbenchState>((set, get) => {
  const applyResult = (matrix: number[][], palette: AknColor[]) => {
    set({ matrix, palette: paletteFrom(palette), busy: false, dirty: true })
  }

  if (!runFullDebounced) {
    runFullDebounced = debounce((source: SourceImage, params: AknConvertParams) => {
      set({ busy: true })
      convertImage('full', source, params).then((res) => {
        if (res.matrix.length > 0) applyResult(res.matrix, res.palette)
        else set({ busy: false })
      })
    }, 350)
  }

  return {
    projectId: null,
    projectName: '未命名作品',
    params: { ...DEFAULT_PARAMS },
    palette: paletteFrom([]),
    matrix: [],
    source: null,
    thumbnail: null,
    busy: false,
    dirty: false,
    works: [],
    selectedColorIndex: 0,
    tool: 'paint',
    showGrid: true,
    toast: null,

    setShowGrid: (v) => set({ showGrid: v }),

    setParams: (patch) => {
      const params = { ...get().params, ...patch }
      set({ params, dirty: true })
      // 实时预览：行/列或算法参数变化时自动重新转换
      if (get().source) runFullDebounced!(get().source!, params)
    },

    setImage: async (file) => {
      const source = await readImageFile(file)
      // 按原图比例初始化行列
      const ratio = source.height / source.width
      const params = { ...get().params }
      params.rows = Math.max(10, Math.round(params.stitches * ratio))
      set({ source, params, busy: true, dirty: true, selectedColorIndex: 0 })
      get().showToast('图片已加载，正在转换…')
      convertImage('full', source, params).then((res) => {
        if (res.matrix.length > 0) applyResult(res.matrix, res.palette)
        else set({ busy: false })
      })
    },

    setMatrix: (matrix, palette) => set({ matrix, palette: paletteFrom(palette), dirty: true }),

    paintCell: (row, col) => {
      const { matrix, palette, selectedColorIndex, tool } = get()
      if (tool === 'pick') {
        const idx = matrix[row]?.[col]
        if (idx != null && idx >= 0) set({ selectedColorIndex: idx, tool: 'paint' })
        return
      }
      if (!matrix[row] || matrix[row][col] === selectedColorIndex) return
      if (!palette.colors.some((c) => c.index === selectedColorIndex)) return
      const next = matrix.map((r, y) => (y === row ? r.map((v, x) => (x === col ? selectedColorIndex : v)) : r))
      set({ matrix: next, dirty: true })
    },

    setSelectedColorIndex: (i) => set({ selectedColorIndex: i }),
    setTool: (t) => set({ tool: t }),

    updateColor: (index, hex) => {
      const palette = get().palette
      const r = parseInt(hex.slice(1, 3), 16)
      const g = parseInt(hex.slice(3, 5), 16)
      const b = parseInt(hex.slice(5, 7), 16)
      const colors = palette.colors.map((c) => (c.index === index ? { ...c, hex, r, g, b } : c))
      set({ palette: { ...palette, colors }, dirty: true })
      if (get().source) runFullDebounced!(get().source!, get().params)
    },

    renameColor: (index, name) => {
      const palette = get().palette
      const colors = palette.colors.map((c) => (c.index === index ? { ...c, name } : c))
      set({ palette: { ...palette, colors }, dirty: true })
    },

    setColorCount: (n) => {
      const params = { ...get().params, colorCount: n }
      set({ params, dirty: true })
      if (get().source) runFullDebounced!(get().source!, params)
    },

    setProjectName: (name) => set({ projectName: name, dirty: true }),

    save: async () => {
      const s = get()
      const project = {
        id: s.projectId ?? newId(),
        name: s.projectName,
        version: 1 as const,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        params: s.params,
        palette: s.palette,
        matrix: s.matrix,
        originalImage: null,
        thumbnail: s.matrix.length ? makeThumbnail(s.matrix, s.palette.colors) : null,
      }
      await saveProject(project)
      set({ projectId: project.id, dirty: false })
      await get().refreshWorks()
      get().showToast(`已保存到本地：${project.name}`)
    },

    open: async (id) => {
      const p = await loadProject(id)
      if (!p) return
      set({
        projectId: p.id,
        projectName: p.name,
        params: p.params,
        palette: p.palette,
        matrix: p.matrix,
        source: null,
        thumbnail: p.thumbnail,
        dirty: false,
        selectedColorIndex: p.palette.colors[0]?.index ?? 0,
      })
      get().showToast(`已打开：${p.name}`)
    },

    remove: async (id) => {
      await deleteProject(id)
      if (get().projectId === id) set({ projectId: null, matrix: [], source: null, thumbnail: null })
      await get().refreshWorks()
      get().showToast('作品已删除')
    },

    refreshWorks: async () => {
      const works = await listProjects()
      set({ works })
    },

    newProject: () => {
      set({
        projectId: null,
        projectName: '未命名作品',
        params: { ...DEFAULT_PARAMS },
        palette: paletteFrom([]),
        matrix: [],
        source: null,
        thumbnail: null,
        dirty: false,
        selectedColorIndex: 0,
      })
    },

    showToast: (msg) => {
      set({ toast: msg })
      setTimeout(() => {
        if (get().toast === msg) set({ toast: null })
      }, 2400)
    },
  }
})
