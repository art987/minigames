/**
 * IndexedDB 持久化层（原生 API，无第三方依赖）
 * 数据库：artknit-studio / 对象仓库：projects
 * 关闭浏览器后作品仍然存在。
 */
import type { AknProject, AknProjectMeta } from '../types/akn'

const DB_NAME = 'artknit-studio'
const DB_VERSION = 1
const STORE = 'projects'

let dbPromise: Promise<IDBDatabase> | null = null

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: 'id' })
      }
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => {
      dbPromise = null
      reject(req.error)
    }
  })
  return dbPromise
}

function tx(db: IDBDatabase, mode: IDBTransactionMode) {
  return db.transaction(STORE, mode).objectStore(STORE)
}

export async function saveProject(project: AknProject): Promise<void> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readwrite').put(project)
    req.onsuccess = () => resolve()
    req.onerror = () => reject(req.error)
  })
}

export async function loadProject(id: string): Promise<AknProject | null> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readonly').get(id)
    req.onsuccess = () => resolve((req.result as AknProject) ?? null)
    req.onerror = () => reject(req.error)
  })
}

export async function deleteProject(id: string): Promise<void> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readwrite').delete(id)
    req.onsuccess = () => resolve()
    req.onerror = () => reject(req.error)
  })
}

export async function listProjects(): Promise<AknProjectMeta[]> {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readonly').getAll()
    req.onsuccess = () => {
      const all = (req.result as AknProject[]) ?? []
      const metas: AknProjectMeta[] = all.map((p) => ({
        id: p.id,
        name: p.name,
        updatedAt: p.updatedAt,
        stitches: p.params.stitches,
        rows: p.params.rows,
        colorCount: p.palette.colors.length,
        thumbnail: p.thumbnail,
      }))
      metas.sort((a, b) => b.updatedAt - a.updatedAt)
      resolve(metas)
    }
    req.onerror = () => reject(req.error)
  })
}

export function newId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}
